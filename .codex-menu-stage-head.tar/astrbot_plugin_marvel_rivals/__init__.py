"""AstrBot plugin package."""

